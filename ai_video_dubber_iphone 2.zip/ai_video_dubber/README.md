# AI Video Dubber (iPhone web app)

This is a deployable starter app. Open the deployed HTTPS address in Safari on iPhone. It supports:
- MP4/MOV/WebM upload
- Automatic source-language detection and speech transcription (Whisper)
- Multi-language translation (Google Translate via deep-translator)
- AI speech generation (Microsoft Edge TTS voices)
- One downloadable MP4 per selected target language

## Important
This is a server-backed web app, not an offline iPhone app. The iPhone browser is the interface; transcription, translation, and rendering run on the server. The included starter uses third-party online services for translation and TTS, so availability, language quality, and usage policies may vary. Do not upload private or copyrighted videos unless you have permission. For production use, add authentication, upload limits, job queueing, storage cleanup, and a paid/authorized translation and TTS provider.

## Deploy with Docker
1. Put this folder in a GitHub repository.
2. Deploy it to a server that supports Docker and has enough RAM/CPU (Whisper `small` can be resource-intensive). A GPU is recommended for faster processing.
3. The server must expose port 8000 and provide HTTPS.
4. Open the deployment URL in Safari on iPhone.

Example local run:
```bash
docker build -t ai-video-dubber .
docker run --rm -p 8000:8000 ai-video-dubber
```
Then visit `http://localhost:8000` from the same computer. For iPhone testing, the server must be reachable on your local network and HTTPS may be required for some browser features.

## Notes
- Each selected language produces a separate MP4.
- The original video picture is kept; its original audio is replaced by synthesized speech.
- This first version does not clone voices, preserve background music, or guarantee perfect lip-sync. Long videos may take a long time and require server memory/storage.

## Deploy on Render (recommended)
1. Upload this project to a GitHub repository.
2. In Render, choose **New → Blueprint** and connect that repository. Render reads `render.yaml`.
3. Review the service settings and approve deployment. The included configuration uses a paid Standard web service (2 GB RAM) because speech recognition/rendering needs more memory than a typical free web instance.
4. Once deployment is live, open the generated `https://....onrender.com` URL in iPhone Safari.

The service uses the `tiny` Whisper model to reduce memory use. Translation and speech generation use external services. For heavier/longer videos, upgrade server resources and add persistent storage, authentication, and upload limits.
