import os, uuid, shutil, subprocess, asyncio
from pathlib import Path
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from faster_whisper import WhisperModel
from deep_translator import GoogleTranslator
import edge_tts

ROOT=Path(__file__).parent
WORK=ROOT/"work"
WORK.mkdir(exist_ok=True)
app=FastAPI(title="AI Video Dubber")
app.mount("/static", StaticFiles(directory=ROOT/"static"), name="static")

LANGS={
 "Khmer":"km","English":"en","Chinese (Simplified)":"zh-CN","Chinese (Traditional)":"zh-TW",
 "Thai":"th","Vietnamese":"vi","Japanese":"ja","Korean":"ko","French":"fr","Spanish":"es",
 "German":"de","Portuguese":"pt","Indonesian":"id","Arabic":"ar","Hindi":"hi","Russian":"ru"
}
VOICES={
 "km":"km-KH-SreymomNeural","en":"en-US-AriaNeural","zh-CN":"zh-CN-XiaoxiaoNeural",
 "zh-TW":"zh-TW-HsiaoChenNeural","th":"th-TH-PremwadeeNeural","vi":"vi-VN-HoaiMyNeural",
 "ja":"ja-JP-NanamiNeural","ko":"ko-KR-SunHiNeural","fr":"fr-FR-DeniseNeural",
 "es":"es-ES-ElviraNeural","de":"de-DE-KatjaNeural","pt":"pt-BR-FranciscaNeural",
 "id":"id-ID-GadisNeural","ar":"ar-EG-SalmaNeural","hi":"hi-IN-SwaraNeural",
 "ru":"ru-RU-SvetlanaNeural"
}
MODEL=None

def ffmpeg(args):
    p=subprocess.run(["ffmpeg","-y","-hide_banner","-loglevel","error",*map(str,args)],capture_output=True,text=True)
    if p.returncode: raise RuntimeError(p.stderr[-1800:])

def get_model():
    global MODEL
    if MODEL is None:
        MODEL=WhisperModel(os.getenv("WHISPER_MODEL","small"), device="cpu", compute_type="int8")
    return MODEL

async def synthesize(text, lang, out):
    voice=VOICES.get(lang, "en-US-AriaNeural")
    await edge_tts.Communicate(text, voice).save(str(out))

@app.get("/", response_class=HTMLResponse)
def home():
    return (ROOT/"static"/"index.html").read_text(encoding="utf-8")

@app.post("/api/dub")
async def dub(video: UploadFile=File(...), languages: str=Form(...)):
    if not video.filename.lower().endswith((".mp4",".mov",".m4v",".webm")):
        raise HTTPException(400,"Please upload an MP4 or supported video file.")
    selected=[x for x in languages.split(",") if x in LANGS]
    if not selected: raise HTTPException(400,"Choose at least one target language.")
    job=WORK/str(uuid.uuid4()); job.mkdir()
    src=job/"source.mp4"
    with src.open("wb") as f: shutil.copyfileobj(video.file,f)
    try:
        model=get_model()
        segments, info=model.transcribe(str(src), vad_filter=True, beam_size=5)
        segs=[{"start":float(s.start),"end":float(s.end),"text":s.text.strip()} for s in segments if s.text.strip()]
        if not segs: raise RuntimeError("No speech was detected in this video.")
        outputs=[]
        for label in selected:
            code=LANGS[label]
            pieces=[]
            for i,s in enumerate(segs):
                translated=GoogleTranslator(source="auto",target=code).translate(s["text"])
                if not translated: continue
                speech=job/f"{code}_{i}.mp3"
                await synthesize(translated,code,speech)
                pieces.append((s["start"],speech))
            if not pieces: continue
            # Place each generated speech clip at its original segment start time.
            inputs=[]; filters=[]
            for i,(start,path) in enumerate(pieces):
                inputs += ["-i",str(path)]
                delay=max(0,int(start*1000))
                filters.append(f"[{i}:a]adelay={delay}|{delay},apad[a{i}]")
            mix="".join(f"[a{i}]" for i in range(len(pieces)))
            filters.append(f"{mix}amix=inputs={len(pieces)}:duration=longest:normalize=0,volume=1.8[dub]")
            out=job/f"dubbed_{code}.mp4"
            cmd=[]
            for x in inputs: cmd.extend(x if isinstance(x,list) else [x])
            ffmpeg([*cmd,"-filter_complex",";".join(filters),"-map","[dub]","-c:a","aac","-b:a","192k","-vn",job/f"audio_{code}.m4a"])
            # Preserve original video; replace original audio with generated dub.
            ffmpeg(["-i",src,"-i",job/f"audio_{code}.m4a","-map","0:v:0","-map","1:a:0","-c:v","copy","-c:a","aac","-shortest",out])
            outputs.append({"language":label,"url":f"/api/download/{job.name}/{out.name}"})
        return {"detected_language":getattr(info,"language","unknown"),"outputs":outputs}
    except Exception as e:
        raise HTTPException(500,f"Dubbing failed: {e}")

@app.get("/api/download/{job}/{filename}")
def download(job:str,filename:str):
    path=WORK/job/filename
    if not path.is_file() or path.parent.parent!=WORK: raise HTTPException(404,"File not found")
    return FileResponse(path,filename=filename,media_type="video/mp4")
